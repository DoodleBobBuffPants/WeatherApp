//enumeration types for weather
public enum WeatherEnum {
	Wet,
	Foggy,
	Dry;
}